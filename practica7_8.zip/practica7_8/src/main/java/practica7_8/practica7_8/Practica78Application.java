package practica7_8.practica7_8;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Practica78Application {

	public static void main(String[] args) {
		SpringApplication.run(Practica78Application.class, args);
	}

}
