package practica7_8.practica7_8;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Practica78ApplicationTests {

	@Test
	void contextLoads() {
	}

}
