/**
 * 
 */
/**
 * 
 */
module Act3 {
	requires java.xml;
	requires java.desktop;
}